from tkinter import *
from tkinter import filedialog
from tkinter.filedialog import askopenfile
from tkinter.filedialog import asksaveasfile
from PIL import ImageTk,Image


root=Tk()

screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

menu=Menu(root)
root.config(menu=menu)
filemenu=Menu(menu)
menu.add_cascade(label='File',menu=filemenu)
filemenu.add_command(label='New')

def open_file():
    file = askopenfile(mode ='r', filetypes =[('Python Files', '*.py')])
    if file is not None:
        content = file.read()
        print(content)

filemenu.add_command(label='Open',command=lambda:open_file())


def save1():
    files = [('All Files', '*.*'), 
             ('Python Files', '*.py'),
             ('Text Document', '*.txt')]
    file1 = asksaveasfile(filetypes = files, defaultextension = files)


filemenu.add_command(label='Save',command=lambda:save1())
filemenu.add_command(label='Save')


filemenu.add_separator()
filemenu.add_command(label='Exit',command=root.destroy)
helpmenu=Menu(menu)
menu.add_cascade(label='Help',menu=helpmenu)
helpmenu.add_command(label='About')
root.title('Plagiarism Detector')
root.geometry('1300x600')
l1=Label(root,text='Plagiarism Detector',font=('Times New Roman',25))
l1.place(x=30,y=10)
l2_inputfile=Label(root,text='Input file:',font=('Ariel',15))
l2_inputfile.place(x=30,y=60)
l3_outputfile=Label(root,text='Output file:',font=('Ariel',15))
l3_outputfile.place(x=700,y=60)
scrollbar=Scrollbar(root)
scrollbar.pack(side=RIGHT,fill=Y)
a=Text(root,width=60,height=30)
a.place(x=30,y=100)
b=Text(root,)
a.config(yscrollcommand=scrollbar.set)
scrollbar.config(command=a.yview)
b=Text(root,width=60,height=30)
b.place(x=700,y=100)
b.config(yscrollcommand=scrollbar.set)
scrollbar.config(command=b.yview)
root.mainloop()