import tkinter
from tkinter import *
from tkinter.filedialog import askopenfile
from tkinter.ttk import *
from tkinter import filedialog as fd
from tkinter.filedialog import asksaveasfile
root=Tk()
root.title("Plagiarism Detector")
root.iconbitmap(r'D:\Users\Sunitha Manohar\Desktop\playboi.ico')
root.geometry('1300x600')
canvas=Canvas(root,width=1300,height=600)
canvas.grid(row=0,column=0)

text12 = Text(root, height=20,width=50)
text12.place(x=100,y=120)

def Page3():
    root.destroy()
    import page3


def open_text_file():
    # file type
    filetypes = (
        ('text files', '*.txt'),
        ('All files', '*.*')
    )
    # show the open file dialog
    f = fd.askopenfile(filetypes=filetypes)
    # read the text file and show its content on the Text
    text12.insert('1.0', f.read())

open_file1=Label(root,text='Open file:')
open_file1.place(x=98,y=100)

def motion(event):
    x, y = event.x, event.y
    print('{}, {}'.format(x, y))

root.bind('<Motion>', motion)


project_title1=Label(root,text="List of links:")
project_title1.place(x=628,y=100)
search_file2=Text(root,width=50,height=20)
search_file2.place(x=630,y=120)

open_button=Button(root,text='Open',command=open_text_file)
open_button.place(x=200,y=503)


submit_button=Button(root,text='Submit',command=Page3)
submit_button.place(x=100,y=503)
quit_button=Button(root,text='Quit',command=root.destroy)
quit_button.place(x=628,y=503)




root.mainloop()