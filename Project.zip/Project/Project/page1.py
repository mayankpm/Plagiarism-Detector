from tkinter import *
from turtle import title
root=Tk()
root.title("Plagiarism Detector")
root.geometry('1300x600')
 
def nextPage2():
    with open("project_title.txt","a") as f:
        f.write(search_type.get(1.0, "end-1c"))
    root.destroy()
    import page2
 
canvas=Canvas(root,width=1300,height=600)
canvas.grid(row=0,column=0)
searchbro=Label(root,text='Project title name:',font=('Georgia',25))
searchbro.place(x=250,y=300)
search_type=Text(root,width=20,height=1,font=('Georgia',25))
 
 
search_type.place(x=530,y=300)
search_button=Button(root,text='Search',font=('Ariel',15),height=1,command=nextPage2)
search_button.place(x=950,y=300)
 
 
root.mainloop()