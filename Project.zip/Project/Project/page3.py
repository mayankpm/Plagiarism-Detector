from tkinter import *
from tkinter import filedialog
from tkinter.filedialog import askopenfile
from tkinter.filedialog import asksaveasfile
# from turtle import title


root=Tk()
# root.title("Plagiarism Detector")

screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

menu=Menu(root)
root.config(menu=menu)
filemenu=Menu(menu)
menu.add_cascade(label='File',menu=filemenu)
filemenu.add_command(label='New')

def open_file():
    file = askopenfile(mode ='r', filetypes =[('Python Files', '*.py')])
    if file is not None:
        content = file.read()

filemenu.add_command(label='Open',command=lambda:open_file())

def input_file():
    f = open("input_text.txt", "r")
    f2=f.read()
    f.close()
    return f2
f1=input_file()

def numb_link_file():
    f_numb= open("numb_link.txt", "r")
    f2_numb=f_numb.read()
    f_numb.close()
    return f2_numb
f1_numb=numb_link_file()

def dict_link_file():
    f_dict= open("dict_link.txt", "r")
    f2_dict=f_dict.read()
    f_dict.close()
    return f2_dict
f1_dict_str=dict_link_file()
#f1_dict=eval(f1_dict_str)


def dic():
    #global f1p
    #g_dict=google_dict(f1)
    f1_dict=eval(dict_link_file())
    for number,link in f1_dict.items():
        if str(number)==f1_numb:
            return link
dic1=dic()

def web_scraping():
    import requests
    res = requests.get(dic1)
    res.text
    import bs4
    soup = bs4.BeautifulSoup(res.text,"lxml")
    soup.select('p')
    title=soup.select('p')
    data=[]
    for i in soup.find_all('p', class_=''):
        data.append(i.text)
    # data=title[3].getText()
    return data


def save1():
    files = [('All Files', '*.*'), 
             ('Python Files', '*.py'),
             ('Text Document', '*.txt')]
    file1 = asksaveasfile(filetypes = files, defaultextension = files)


filemenu.add_command(label='Save',command=lambda:save1())
filemenu.add_command(label='Save')


filemenu.add_separator()
filemenu.add_command(label='Exit',command=root.destroy)
helpmenu=Menu(menu)
menu.add_cascade(label='Help',menu=helpmenu)
helpmenu.add_command(label='About')
root.title('Plagiarism Detector')
root.geometry('1300x600')
l1=Label(root,text='Plagiarism Detector',font=('Calibri',25))
l1.place(x=30,y=10)
l2_inputfile=Label(root,text='Input file:',font=('Calibri',15))
l2_inputfile.place(x=30,y=60)
l3_outputfile=Label(root,text='Output file:',font=('Calibri',15))
l3_outputfile.place(x=700,y=60)
scrollbar=Scrollbar(root)
scrollbar.pack(side=RIGHT,fill=Y)
a=Text(root,width=60,height=30)
a.insert("1.0",f1)
a.place(x=30,y=100)
a.config(yscrollcommand=scrollbar.set)
scrollbar.config(command=a.yview)
b=Text(root,width=60,height=30)
raw_data=web_scraping()
data='\n'.join(raw_data)
b.insert('1.0',data)
b.place(x=700,y=100)
b.config(yscrollcommand=scrollbar.set)
scrollbar.config(command=b.yview)

def quit_fn():
    import os
    os.remove("project_title.txt")
    os.remove("input_text.txt")
    os.remove(".google-cookie")
    os.remove("numb_link.txt")
    os.remove("dict_link.txt")
    root.destroy()

quit_button=Button(root,text='Quit',width=5,command=quit_fn)
quit_button.place(x=575,y=350)




root.mainloop()