
from tkinter import *
from tkinter.ttk import *
from tkinter import filedialog as fd
from turtle import title
import json
root=Tk()
root.title("Plagiarism Detector")
#root.iconbitmap(r'D:\Users\Sunitha Manohar\Desktop\playboi.ico')
root.geometry('1300x600')
canvas=Canvas(root,width=1300,height=600)
canvas.grid(row=0,column=0)
 
text12 = Text(root,width=50,height=20)
text12.place(x=100,y=120)
 
def Page3():
    with open("input_text.txt","a") as f:
        f.write(text12.get(1.0, "end-1c"))
    with open("numb_link.txt","w") as g:
        g.write(search_typep.get(1.0, "end-1c"))
    with open("dict_link.txt","w") as h:
        h.write(json.dumps(dict_p))
    root.destroy()
    import page3
 
 
def open_text_file():
    # file type
    filetypes = [("Text Files", "*.txt"), ("All Files", "*.*"), ("Python Files", "*.py")]
    # open file dialog
    filepath = fd.askopenfilename(filetypes=filetypes)
    # open the file
    f = open(filepath, 'r')
    # read the contents of the file
    contents = f.read()
    # close the file
    f.close()
    # read the text file and show its content on the Text
    text12.insert('1.0', contents)
open_file1=Label(root,text='Open file:')
open_file1.place(x=98,y=100)


empty=[];linr=[];l0=[]
def google(fun):
    try:
        from googlesearch import search
    except BaseException as e:
        print("Error Code: ",e)
    for j in search(fun,num=2, stop=5, pause=2):
        linr.append(j)
        #linr.reverse()
    l0.insert(0, "1) "+linr[0]);l0.insert(1, "2) "+linr[1]);l0.insert(2, "3) "+linr[2]);l0.insert(3, "4) "+linr[3]);l0.insert(4, "5) "+linr[4])
    for x0 in l0:    
        empty.append(x0+"\n"+"\n") 
    return empty
 
project_title1=Label(root,text="List of links:")
project_title1.place(x=628,y=100)
search_file2=Text(root,width=60,height=20)
 
def project_title2():
    f = open("project_title.txt", "r")
    f2=f.read()
    f.close()
    return f2
f1=project_title2()
google(f1)
 

for i in empty:
    search_file2.insert('1.0',i)
search_file2.place(x=630,y=120)
 
open_button=Button(root,text='Open',command=open_text_file)
open_button.place(x=200,y=503)
 
 
submit_button=Button(root,text='Submit',command=Page3)
submit_button.place(x=100,y=503)
quit_button=Button(root,text='Quit',command=root.destroy)
quit_button.place(x=628,y=503)
 

#search_button=Button(root,text='Search',command=Page3)
#search_button.place(x=1000,y=503)


searchbrop=Label(root,text='Enter the no of the link:',font=('Calibri',12))
searchbrop.place(x=800,y=503)
search_typep=Text(root,width=2,height=1,font=('Calibri',12))
search_typep.place(x=960,y=503)


num_link= search_typep.get(1.0, "end-1c")



empty_d=[];l0_d=[];numb=[1,2,3,4,5]
def google_dict(title_dict):
    try:
        from googlesearch import search
        linr_dict=[]


    except BaseException as e:
        print("Error Code: ",e)
    for j_dict in search(title_dict,num=2, stop=5, pause=2):
        linr_dict.append(j_dict)
    lin_dict=linr_dict[::-1]   
    result=dict(zip(numb,lin_dict))
    return result
dict_p=google_dict(f1)


# print(dic1)
root.mainloop()